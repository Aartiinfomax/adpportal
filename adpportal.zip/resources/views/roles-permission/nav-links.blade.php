<div class="container m-3">
    <a class="btn btn-primary" href="{{ url('roles') }}">Roles</a>
    <a class="btn btn-primary" href="{{ url('permissions') }}">Permissions</a>
    <a class="btn btn-primary" href="{{ url('users') }}">Users</a>
</div>