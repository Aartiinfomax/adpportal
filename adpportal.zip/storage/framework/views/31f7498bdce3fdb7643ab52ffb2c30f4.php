<?php echo e($slot); ?>

<?php /**PATH E:\wamp64\www\Aarti\adpportal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>