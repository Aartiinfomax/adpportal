<div class="container m-3">
    <a class="btn btn-primary" href="<?php echo e(url('roles')); ?>">Roles</a>
    <a class="btn btn-primary" href="<?php echo e(url('permissions')); ?>">Permissions</a>
    <a class="btn btn-primary" href="<?php echo e(url('users')); ?>">Users</a>
</div><?php /**PATH E:\wamp64\www\Aarti\adpportal\resources\views/roles-permission/nav-links.blade.php ENDPATH**/ ?>