

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>

            <?php endif; ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="page-header">
        <div class="row justify-content-center">
            <div class="col-sm-6">
                <h3>Master Dance Style</h3>
            </div>
            <!-- Create dance style start -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create Masters')): ?>
            <div class="col-sm-6">
                <div class="modal fade" id="insertmodel" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Dance Style Create</h5>
                                <button class="btn-close" type="button" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('master-dancestyle-create')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-form-label pt-0" for="">Dance Style Name
                                                    (*)</label>
                                                <input class="form-control" type="text" name="dancestylename"
                                                    placeholder="Dance Style Name" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button"
                                        data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="submit">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="bookmark">
                    <button class="btn btn-square btn-primary btn-xs" type="button" data-bs-toggle="modal"
                        data-bs-target="#insertmodel"><i class="fa fa-plus-circle"></i> Create Dance
                        Style</button>
                </div>
            </div>
            <?php endif; ?>
            <!-- Create dance style end -->
        </div>
    </div>
</div>
<div class="container">
    <div class="page-header">
        <div class="row justify-content-center">
            <div class="col-sm-6">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Dance style Name</th>
                            <th>Added By</th>
                            <th>Last Updated By</th>
                            <th>Action</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dancestyles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dancestyle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dancestyle->dancestyleName); ?></td>
                                <td><?php echo e($dancestyle->addedby->name); ?></td>
                                <td><?php echo e($dancestyle->lastupdatedby->name ?? 'N/A'); ?></td>
                                <!-- edit dance style start -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Masters')): ?>
                                <td>
                                    <div class="modal fade" id="dancestyleedit<?php echo e($dancestyle->dancestyleId); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalCenter" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog modal-lg" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Dance Style Edit</h5>
                                                    <button class="btn-close" type="button" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(url('master-dancestyle-update')); ?>" method="POST"
                                                    enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <label class="col-form-label pt-0" for="">Dance Style
                                                                        Name
                                                                        (*)</label>
                                                                    <input class="form-control" type="text"
                                                                        name="dancestylename" placeholder="Dance Style Name" value="<?php echo e($dancestyle->dancestyleName); ?>"
                                                                        required="">
                                                                        <input type="hidden" name="dancestyleid" value="<?php echo e($dancestyle->dancestyleId); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" type="button"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button class="btn btn-primary" type="submit">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#dancestyleedit<?php echo e($dancestyle->dancestyleId); ?>">Edit</a>
                                </td>
                                <?php endif; ?>
                                <!-- edit dance style end -->
                                <!-- status dance style start -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Softdelete Masters')): ?>
                                <td>
                                <div class="modal fade" id="statusmodal<?php echo e($dancestyle->dancestyleId); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenter" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title">Brand Status</h5>
                                          <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('master-dancestyle-chnagestatus')); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <div class="modal-body">
                                            <?php if($dancestyle->dancestyleStatus == '1'): ?>
                                            <p><?php echo e($dancestyle->dancestyleName); ?> is in <span class=" ">Active</span> status</p>
                                            <p>Do you realy want to <span class=" ">De-active</span> Dance Style </p>
                                            <input type="hidden" name="status" value="0">
                                            <input type="hidden" name="dancestyleid" value="<?php echo e($dancestyle->dancestyleId); ?>">
                                            <?php else: ?>
                                            <p><?php echo e($dancestyle->dancestyleName); ?> is in <span class=" ">De-active</span> status</p>
                                            <p>Do you realy want to <span class=" ">Active</span> Dance Style </p>
                                            <input type="hidden" name="status" value="1">
                                            <input type="hidden" name="dancestyleid" value="<?php echo e($dancestyle->dancestyleId); ?>">
                                            <?php endif; ?>
                                          </div>
                                          <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                            <button class="btn btn-primary" type="submit">Yes</button>
                                          </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                    <?php if($dancestyle->dancestyleStatus == '1'): ?>
                                    <a href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#statusmodal<?php echo e($dancestyle->dancestyleId); ?>">Active</a>
                                    <?php else: ?>
                                    <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#statusmodal<?php echo e($dancestyle->dancestyleId); ?>">deactivate</a>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <!-- status dance style end -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Aarti\adpportal\resources\views/masters/dancestyle.blade.php ENDPATH**/ ?>