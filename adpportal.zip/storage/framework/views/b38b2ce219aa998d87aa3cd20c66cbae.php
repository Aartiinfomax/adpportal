

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>

            <?php endif; ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="page-header">
        <div class="row justify-content-center">
            <div class="col-sm-6">
                <h3>Master Dance Level</h3>
            </div>
            <!-- Create dance Level start -->
            <div class="col-sm-6">
                <div class="modal fade" id="insertmodel" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Dance Level Create</h5>
                                <button class="btn-close" type="button" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('master-dancelevel-create')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-form-label pt-0" for="">Dance Level Name
                                                    (*)</label>
                                                <input class="form-control" type="text" name="dancelevelname"
                                                    placeholder="Dance Level Name" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button"
                                        data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="submit">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="bookmark">
                    <button class="btn btn-square btn-primary btn-xs" type="button" data-bs-toggle="modal"
                        data-bs-target="#insertmodel"><i class="fa fa-plus-circle"></i> Create Dance
                        Level</button>
                </div>
            </div>
            <!-- Create dance Level end -->
        </div>
    </div>
</div>
<div class="container">
    <div class="page-header">
        <div class="row justify-content-center">
            <div class="col-sm-6">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Dance Level Name</th>
                            <th>Added By</th>
                            <th>Last Updated By</th>
                            <th>Action</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dancelevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dancelevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dancelevel->dancelevelName); ?></td>
                                <td><?php echo e($dancelevel->addedby->name); ?></td>
                                <td><?php echo e($dancelevel->lastupdatedby->name ?? 'N/A'); ?></td>
                                <!-- edit dance Level start -->
                                <td>
                                    <div class="modal fade" id="danceleveledit<?php echo e($dancelevel->dancelevelId); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalCenter" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog modal-lg" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Dance Level Edit</h5>
                                                    <button class="btn-close" type="button" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(url('master-dancelevel-update')); ?>" method="POST"
                                                    enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <label class="col-form-label pt-0" for="">Dance Level
                                                                        Name
                                                                        (*)</label>
                                                                    <input class="form-control" type="text"
                                                                        name="dancelevelname" placeholder="Dance Level Name" value="<?php echo e($dancelevel->dancelevelName); ?>"
                                                                        required="">
                                                                        <input type="hidden" name="dancelevelid" value="<?php echo e($dancelevel->dancelevelId); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" type="button"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button class="btn btn-primary" type="submit">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#danceleveledit<?php echo e($dancelevel->dancelevelId); ?>">Edit</a>
                                </td>
                                <!-- edit dance level end -->
                                <!-- status dance level start -->
                                <td>
                                <div class="modal fade" id="statusmodal<?php echo e($dancelevel->dancelevelId); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenter" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title">Brand Status</h5>
                                          <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('master-dancelevel-chnagestatus')); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <div class="modal-body">
                                            <?php if($dancelevel->dancelevelStatus == '1'): ?>
                                            <p><?php echo e($dancelevel->dancelevelName); ?> is in <span class=" ">Active</span> status</p>
                                            <p>Do you realy want to <span class=" ">De-active</span> Dance Level </p>
                                            <input type="hidden" name="status" value="0">
                                            <input type="hidden" name="dancelevelid" value="<?php echo e($dancelevel->dancelevelId); ?>">
                                            <?php else: ?>
                                            <p><?php echo e($dancelevel->dancelevelName); ?> is in <span class=" ">De-active</span> status</p>
                                            <p>Do you realy want to <span class=" ">Active</span> Dance Level </p>
                                            <input type="hidden" name="status" value="1">
                                            <input type="hidden" name="dancelevelid" value="<?php echo e($dancelevel->dancelevelId); ?>">
                                            <?php endif; ?>
                                          </div>
                                          <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                            <button class="btn btn-primary" type="submit">Yes</button>
                                          </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                    <?php if($dancelevel->dancelevelStatus == '1'): ?>
                                    <a href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#statusmodal<?php echo e($dancelevel->dancelevelId); ?>">Active</a>
                                    <?php else: ?>
                                    <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#statusmodal<?php echo e($dancelevel->dancelevelId); ?>">deactivate</a>
                                    <?php endif; ?>
                                </td>
                                <!-- status dance level end -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Aarti\adpportal\resources\views/masters/dancelevel.blade.php ENDPATH**/ ?>