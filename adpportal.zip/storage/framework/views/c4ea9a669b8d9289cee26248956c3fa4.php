

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                <h1>Create roles
                    <a href="<?php echo e(url('roles')); ?>" class="btn btn-primary float-end">Back</a>
                    </h1>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('updaterole', [$role->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="">Role Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($role->name); ?>">
                        </div>
                        <div class="mb-3">
                            <button type="sunmit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Aarti\adpportal\resources\views/roles/edit.blade.php ENDPATH**/ ?>