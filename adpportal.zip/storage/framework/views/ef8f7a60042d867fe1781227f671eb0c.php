

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>

            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h1>Role: <?php echo e($role->name); ?>

                        <a href="<?php echo e(url('roles')); ?>" class="btn btn-primary float-end">Back</a>
                    </h1>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('givepermissionstorole', [$role->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="">Permissions</label>
                            <div class="row">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="col-md-2">
                                    <label for="">
                                    <input type="checkbox" 
                                    name="permission[]" 
                                    class="" 
                                    value="<?php echo e($permission->name); ?>"
                                    <?php echo e(in_array($permission->id, $rolePermissions) ? 'checked' : ''); ?>

                                    >
                                    <?php echo e($permission->name); ?>

                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="sunmit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Aarti\adpportal\resources\views/roles-permission/roles/add-permissions.blade.php ENDPATH**/ ?>