<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Roles and Permisson')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="container m-3">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View Role')): ?>
                            <a class="btn btn-primary" href="<?php echo e(url('roles')); ?>">Roles</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View Permission')): ?>
                            <a class="btn btn-primary" href="<?php echo e(url('permissions')); ?>">Permissions</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View User')): ?>
                            <a class="btn btn-primary" href="<?php echo e(url('users')); ?>">Users</a>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Masters')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="container m-3">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View Masters')): ?>
                            <a class="btn btn-primary" href="<?php echo e(url('master-dance-style')); ?>">Dance Styles</a>
                            <a class="btn btn-primary" href="<?php echo e(url('master-dance-level')); ?>">Dance Levels</a>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Aarti\adpportal\resources\views/home.blade.php ENDPATH**/ ?>